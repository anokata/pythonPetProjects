from src.app import app

app.run()
